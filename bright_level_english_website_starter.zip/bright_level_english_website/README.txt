BRIGHT LEVEL ENGLISH — STARTER WEBSITE

Files:
- index.html: complete responsive one-page website.
- assets/ble-logo.jpg: original logo image supplied in the conversation.

Preview:
Open index.html in a web browser.

Before publishing:
1. Add the approved WhatsApp number and email address.
2. Confirm the academy location/service area and course information.
3. Review every statement and image/brand asset.
4. Publish the folder using a static hosting service such as GitHub Pages.
5. A custom .com domain is optional and normally has a separate registration fee.

This starter site does not collect or store student data. Do not add student personal information to a public website.
